package com.example.sensor;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sensor.Database.SensorDatabase;
import com.example.sensor.Model.GeoModel;
import com.example.sensor.Model.LightModel;
import com.example.sensor.Model.ProximityModel;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Part2_Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Part2_Fragment extends Fragment implements SensorEventListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String TAG = "Fragment2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private View rootView;
    SensorManager sensorManager;
    Sensor rotationSensor;
    TextView feed;
    private static final int REQUEST_CODE_PERMISSIONS = 123;

    public Part2_Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Part2_Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Part2_Fragment newInstance(String param1, String param2) {
        Part2_Fragment fragment = new Part2_Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_part2_, container, false);
        feed = rootView.findViewById(R.id.feedback);

        // Check if the app has the necessary permissions
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
            // Request the necessary permissions
            requestPermissions(new String[] {Manifest.permission.ACCESS_NETWORK_STATE, Manifest.permission.INTERNET},
                    REQUEST_CODE_PERMISSIONS);
        } else {
            sensorManager = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
            rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);

            if (rotationSensor != null) {
                sensorManager.registerListener((SensorEventListener) Part2_Fragment.this, rotationSensor, SensorManager.SENSOR_DELAY_NORMAL);
                Toast.makeText(getActivity(), "Rotation Vector Sensor Started (PART 2)", Toast.LENGTH_SHORT).show();
                Log.i(TAG, "Rotation Vector Sensor Started (PART 2)");
            } else {
                Toast.makeText(getActivity(), "Rotation Vector Sensor Not Supported", Toast.LENGTH_SHORT).show();
                Log.i(TAG, "Rotation Vector Sensor Not Supported");
            }

        }

        return rootView;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permissions granted, do whatever you want here
                // ...
            } else {
                // Permissions denied, handle this situation
                // ...
            }
        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        if(sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){
            float[] rotationMatrix = new float[9];
            float[] orientation = new float[3];

            SensorManager.getRotationMatrixFromVector(rotationMatrix, sensorEvent.values);
            SensorManager.getOrientation(rotationMatrix, orientation);

            float directionsAngle = (float) Math.toDegrees(orientation[0]);
            float degreeToNorth = (directionsAngle + 360) % 360;
            float direction = degreeToNorth - getMagneticDeclination(getContext());
            direction = (direction + 360) % 360;

            String feedbackText = "";
            if (direction > 3 && direction < 177) {
                feedbackText += "Rotate " + direction + "° Left";
                feed.setTypeface(null, Typeface.ITALIC);
            } else if (direction > 183 && direction < 357) {
                feedbackText += "Rotate " + (360 - direction) + "° Right";
                feed.setTypeface(null, Typeface.ITALIC);
            } else if (direction >= 357 || direction < 3) {
                feedbackText = "SUCCESS!\nYou are facing the North Pole.";
                feed.setTypeface(null, Typeface.BOLD);
            } else if (direction >= 177 && direction < 183) {
                feedbackText = "You are facing SOUTH\n" + "Rotate by ~180° to Left or Right";
                feed.setTypeface(null, Typeface.ITALIC);
            }
            feed.setText(feedbackText);
        }
    }

    private float getMagneticDeclination(Context context) {
        float declination = 0.0f;
        GeomagneticField geoField = new GeomagneticField(
                Double.valueOf(0.0).floatValue(),
                Double.valueOf(0.0).floatValue(),
                Double.valueOf(0.0).floatValue(),
                System.currentTimeMillis()
        );
        declination = geoField.getDeclination();
        return declination;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(getActivity(), "Rotation Vector Sensor Stopped (PART 2)", Toast.LENGTH_SHORT).show();
        Log.i(TAG, "Rotation Vector Sensor Stopped (PART 2)");
        sensorManager.unregisterListener((SensorEventListener) Part2_Fragment.this,sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR));
    }
}