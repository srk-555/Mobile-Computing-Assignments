package com.example.sensor.DAOs;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.sensor.Model.GeoModel;

import java.util.List;

@Dao
public interface GeoDAO {

    @Insert
    void insert(GeoModel geoModel);

    @Query("Select * from (Select * from geoTable Order By id Desc Limit 10) Var1 Order By id Asc")
    List<GeoModel> getGeoVector();
}
