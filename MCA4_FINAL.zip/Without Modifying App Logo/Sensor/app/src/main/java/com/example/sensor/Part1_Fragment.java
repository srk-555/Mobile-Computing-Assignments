package com.example.sensor;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.example.sensor.Database.SensorDatabase;
import com.example.sensor.Model.GeoModel;
import com.example.sensor.Model.LightModel;
import com.example.sensor.Model.ProximityModel;
import java.text.DecimalFormat;

public class Part1_Fragment extends Fragment implements SensorEventListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private View rootView;


    ToggleButton lightButton,proxiButton,geoButton;
    TextView geoX, geoY, geoZ, light, proximity;
    private static final String TAG = "Fragment1";
    private static final DecimalFormat df = new DecimalFormat("0.0000");
    SensorManager sensorManager;
    Sensor geoSensor,lightSensor,proximitySensor;

    SensorDatabase sensorDatabase;
    public Part1_Fragment() {
        // Required empty public constructor
    }

    public static Part1_Fragment newInstance(String param1, String param2) {
        Part1_Fragment fragment = new Part1_Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_part1_, container, false);

        geoButton = rootView.findViewById(R.id.toggleButton_geo);
        lightButton = rootView.findViewById(R.id.toggleButton_light);
        proxiButton = rootView.findViewById(R.id.toggleButton_proxi);

        geoX = rootView.findViewById(R.id.geo_text1);
        geoY = rootView.findViewById(R.id.geo_text2);
        geoZ = rootView.findViewById(R.id.geo_text3);

        light = rootView.findViewById(R.id.light_text);
        proximity = rootView.findViewById(R.id.proximity_text);

        sensorManager = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);

        proxiButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
                    if(proximitySensor!=null){
                        sensorManager.registerListener((SensorEventListener) Part1_Fragment.this, proximitySensor,SensorManager.SENSOR_DELAY_NORMAL);
                        Toast.makeText(getActivity(), "Proximity Sensor Started", Toast.LENGTH_SHORT).show();
                        Log.i(TAG, "Proximity Sensor Started");
                    }
                    else{
                        Log.i(TAG, "Proximity Not Suported");
                        Toast.makeText(getActivity(), "Proximity Sensor Not Supported", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    stop(1);
                    Toast.makeText(getActivity(), "Proximity Sensor Stopped", Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "Proximity Sensor Stopped");
                    proximity.setText("Proximity");
                }
            }
        });

        lightButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
                    if(lightSensor!=null){
                        sensorManager.registerListener((SensorEventListener) Part1_Fragment.this, lightSensor,SensorManager.SENSOR_DELAY_NORMAL);
                        Toast.makeText(getActivity(), "Light Sensor Started", Toast.LENGTH_SHORT).show();
                        Log.i(TAG, "Light Sensor Started");
                    }
                    else{
                        Log.i(TAG, "Light Sensor Not Suported");
                        Toast.makeText(getActivity(), "Light Sensor Not Supported", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    stop(2);
                    Toast.makeText(getActivity(), "Light Sensor Stopped", Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "Light Sensor Stopped");
                    light.setText("Light");
                }
            }
        });

        geoButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    geoSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
//                    Log.e(TAG, "geoSensor is - "+ String.valueOf(geoSensor));
                    if (geoSensor != null) {
                        sensorManager.registerListener((SensorEventListener) Part1_Fragment.this, geoSensor, SensorManager.SENSOR_DELAY_NORMAL);
                        Toast.makeText(getActivity(), "Rotation Vector Sensor Started", Toast.LENGTH_SHORT).show();
                        Log.i(TAG, "Rotation Vector Sensor Started");
                    } else {
                        Toast.makeText(getActivity(), "Rotation Vector Sensor Not Supported", Toast.LENGTH_SHORT).show();
                        Log.i(TAG, "Rotation Vector Sensor Not Supported");
                    }
                } else {
                    stop(3);
                    Toast.makeText(getActivity(), "Rotation Vector Sensor Stopped", Toast.LENGTH_SHORT).show();
                    Log.i(TAG, "Rotation Vector Sensor Stopped");
                    geoX.setText("RotX");
                    geoY.setText("RotY");
                    geoZ.setText("RotZ");
                }
            }
        });

        return rootView;
    }
    private void stop(int option){
        if(option ==1)
            sensorManager.unregisterListener((SensorEventListener) Part1_Fragment.this,sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY));

        else if(option ==2)
            sensorManager.unregisterListener((SensorEventListener) Part1_Fragment.this,sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT));

        else if(option ==3)
            sensorManager.unregisterListener((SensorEventListener) Part1_Fragment.this,sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR));
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        if(sensor.getType()==Sensor.TYPE_PROXIMITY){
            sensorDatabase = SensorDatabase.getInstance(getContext());
            float proximityValue = sensorEvent.values[0];
            String proxiString = Float.toString(Float.parseFloat(df.format(proximityValue)));
            proximity.setText(proxiString);

            if (proximityValue<5.0){
                Log.i(TAG, "onSensorChanged: Proximity Recorded is : "+proximityValue);
                ProximityModel pModel = new ProximityModel(Float.parseFloat(proxiString));
                sensorDatabase.proximityDAO().insert(pModel);
            }

        }
        else if(sensor.getType()== Sensor.TYPE_LIGHT){
            sensorDatabase = SensorDatabase.getInstance(getContext());
            float lightValue = sensorEvent.values[0];
            String lightString = Float.toString(Float.parseFloat(df.format(lightValue)));
            light.setText(lightString);

            if(lightValue<6.5){
                Log.i(TAG, "onSensorChanged: Light Recorded is : "+lightValue);
                LightModel lModel = new LightModel(Float.parseFloat(lightString));
                sensorDatabase.lightDAO().insert(lModel);
            }

        }

        else if(sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){
            sensorDatabase = SensorDatabase.getInstance(getContext());
            float gx = sensorEvent.values[0];
            float gy = sensorEvent.values[1];
            float gz = sensorEvent.values[2];

            Log.i(TAG, "onSensorChanged: Rotation Vector Recorded is : "+gx+","+gy+","+gz);
            String geo_x = Float.toString(Float.parseFloat(df.format(gx)));
            String geo_y = Float.toString(Float.parseFloat(df.format(gy)));
            String geo_z = Float.toString(Float.parseFloat(df.format(gz)));
            geoX.setText(geo_x);
            geoY.setText(geo_y);
            geoZ.setText(geo_z);

            GeoModel gModel = new GeoModel(Float.parseFloat(geo_x),Float.parseFloat(geo_y),Float.parseFloat(geo_z));
            sensorDatabase.geoDAO().insert(gModel);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}