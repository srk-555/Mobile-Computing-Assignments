package com.example.sensor.Database;

//import com.example.myapplication.model.AccelModel;
//import com.example.myapplication.myDao.AccelDAO;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.sensor.DAOs.GeoDAO;
import com.example.sensor.DAOs.LightDAO;
import com.example.sensor.DAOs.ProximityDAO;
import com.example.sensor.Model.GeoModel;
import com.example.sensor.Model.LightModel;
import com.example.sensor.Model.ProximityModel;

@Database(entities = {ProximityModel.class, LightModel.class, GeoModel.class},version = 16)
public abstract class SensorDatabase extends RoomDatabase {
    public abstract ProximityDAO proximityDAO();
    public abstract LightDAO lightDAO();
    public abstract GeoDAO geoDAO();
    public static SensorDatabase accelDatabaseinstance;
    public static SensorDatabase getInstance(Context context){

        if(accelDatabaseinstance == null){
            accelDatabaseinstance = Room.databaseBuilder(context.getApplicationContext(), SensorDatabase.class, "sensor_database").fallbackToDestructiveMigration().allowMainThreadQueries().build();
        }

        accelDatabaseinstance.getOpenHelper().getWritableDatabase();   // Force Opening Database for my S22+ device
        return accelDatabaseinstance;

    }
}
