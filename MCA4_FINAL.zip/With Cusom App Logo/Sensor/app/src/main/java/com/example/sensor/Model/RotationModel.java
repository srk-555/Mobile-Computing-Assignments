package com.example.sensor.Model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "rotationTable")
public class RotationModel {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @ColumnInfo(name = "rotX")
    private float geox;

    @ColumnInfo(name = "rotY")
    private float geoy;

    @ColumnInfo(name = "rotZ")
    private float geoz;

    @ColumnInfo(name = "rotCos")
    private float geoCos;

    public RotationModel(){

    }
    public RotationModel(float x, float y, float z, float cos) {
        this.geox = x;
        this.geoy = y;
        this.geoz = z;
        this.geoCos = cos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getGeox() {
        return geox;
    }

    public void setGeox(float geox) {
        this.geox = geox;
    }

    public float getGeoy() {
        return geoy;
    }

    public void setGeoy(float geoy) {
        this.geoy = geoy;
    }

    public float getGeoCos() {
        return geoCos;
    }

    public void setGeoCos(float geoCos) {
        this.geoCos = geoCos;
    }

    public float getGeoz() {
        return geoz;
    }

    public void setGeoz(float geoz) {
        this.geoz = geoz;
    }
}
