package com.example.sensor.DAOs;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;
import com.example.sensor.Model.LightModel;

import java.util.List;

@Dao
public interface LightDAO {
    @Insert
    void insert(LightModel lightModel);

    @Query("Select * from (Select * from lightTable Order By id Desc Limit 10) Var1 Order By id Asc")
    List<LightModel> getLightList();
}
