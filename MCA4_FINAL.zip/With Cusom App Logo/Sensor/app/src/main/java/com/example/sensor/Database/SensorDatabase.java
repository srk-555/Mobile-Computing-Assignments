package com.example.sensor.Database;

//import com.example.myapplication.model.AccelModel;
//import com.example.myapplication.myDao.AccelDAO;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.sensor.DAOs.RotationDAO;
import com.example.sensor.DAOs.LightDAO;
import com.example.sensor.DAOs.ProximityDAO;
import com.example.sensor.Model.RotationModel;
import com.example.sensor.Model.LightModel;
import com.example.sensor.Model.ProximityModel;

@Database(entities = {ProximityModel.class, LightModel.class, RotationModel.class},version = 19)
public abstract class SensorDatabase extends RoomDatabase {
    public abstract ProximityDAO proximityDAO();
    public abstract LightDAO lightDAO();
    public abstract RotationDAO rotationDAO();
    public static SensorDatabase accelDatabaseinstance;
    public static SensorDatabase getInstance(Context context){

        if(accelDatabaseinstance == null){
            accelDatabaseinstance = Room.databaseBuilder(context.getApplicationContext(), SensorDatabase.class, "rotation_database").fallbackToDestructiveMigration().allowMainThreadQueries().build();
        }

        accelDatabaseinstance.getOpenHelper().getWritableDatabase();   // Force Opening Database for my S22+ device
        return accelDatabaseinstance;

    }
}
