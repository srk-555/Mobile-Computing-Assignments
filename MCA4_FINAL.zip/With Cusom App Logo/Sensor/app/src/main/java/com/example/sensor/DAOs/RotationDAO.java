package com.example.sensor.DAOs;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.sensor.Model.RotationModel;

import java.util.List;

@Dao
public interface RotationDAO {

    @Insert
    void insert(RotationModel RotationModel);

    @Query("Select * from (Select * from rotationTable Order By id Desc Limit 10) Var1 Order By id Asc")
    List<RotationModel> getGeoVector();
}
