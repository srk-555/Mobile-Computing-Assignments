package com.example.sensor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private Part1_Fragment part1_frag;
    private Part2_Fragment part2_frag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                switch (item.getItemId()) {
                    case R.id.part1:
                        fragment = new Part1_Fragment();
                        break;
                    case R.id.part2:
                        fragment = new Part2_Fragment();
                        break;
                }
                if (fragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.parentcontainer, fragment)
                            .commit();
                    return true;
                }
                return false;
            }
        };

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

// Load the initial fragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.parentcontainer, new Part1_Fragment())
                .commit();




//        FragmentManager fmanager = getSupportFragmentManager();
//        FragmentTransaction ftransaction = fmanager.beginTransaction();
//        part1_frag = new Part1_Fragment();
//        ftransaction.add(R.id.parentcontainer, part1_frag);
//        ftransaction.commit();
    }





}