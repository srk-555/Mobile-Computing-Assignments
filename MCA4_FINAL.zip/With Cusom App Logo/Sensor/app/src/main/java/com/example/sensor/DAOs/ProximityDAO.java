package com.example.sensor.DAOs;
import com.example.sensor.Model.ProximityModel;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ProximityDAO {
    @Insert
    void insert(ProximityModel accelModel);

    @Query("Select * from (Select * from proximityTable Order By id Desc Limit 10) Var1 Order By id Asc")
    List<ProximityModel> getProximityList();
}

