package com.example.sensor.Model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "lightTable")
public class LightModel {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="id")
    private int id;

    @ColumnInfo(name = "lightValue")
    private float light;

    public LightModel(){

    }
    public LightModel(float lightValue) {
        this.light = lightValue;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getLight() {
        return light;
    }

    public void setLight(float y) {
        this.light = y;
    }

}
