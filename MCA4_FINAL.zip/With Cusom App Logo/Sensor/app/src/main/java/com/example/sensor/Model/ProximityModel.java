package com.example.sensor.Model;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

//@Entity(tableName = "accelTable")
//public class ProximityModel {
//    @PrimaryKey(autoGenerate = true)
//    @ColumnInfo(name="id")
//    private int id;
//
//    @ColumnInfo(name = "x_value")
//    private float x;
//
//    @ColumnInfo(name = "y_value")
//    private float y;
//
//    @ColumnInfo(name = "z_value")
//    private float z;
//
//    public ProximityModel(float x, float y, float z) {
//        this.x = x;
//        this.y = y;
//        this.z = z;
//    }
//
//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public float getX() {
//        return x;
//    }
//
//    public void setX(float x) {
//        this.x = x;
//    }
//
//    public float getY() {
//        return y;
//    }
//
//    public void setY(float y) {
//        this.y = y;
//    }
//
//    public float getZ() {
//        return z;
//    }
//
//    public void setZ(float z) {
//        this.z = z;
//    }
//}

@Entity(tableName = "proximityTable")
public class ProximityModel {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="id")
    private int id;

    @ColumnInfo(name = "proximityValue")
    private float proximity;

    public ProximityModel(){

    }
    public ProximityModel(float proximityValue) {
        this.proximity = proximityValue;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getProximity() {
        return proximity;
    }

    public void setProximity(float y) {
        this.proximity = y;
    }

}
