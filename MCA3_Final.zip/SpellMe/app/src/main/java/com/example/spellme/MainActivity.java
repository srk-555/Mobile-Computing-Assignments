package com.example.spellme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private MainFragment frag1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frag1 = new MainFragment();
        FragmentManager fmanager = getSupportFragmentManager();
        FragmentTransaction ftransaction = fmanager.beginTransaction();

        ftransaction.add(R.id.parentcontainer, frag1);
        ftransaction.commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}