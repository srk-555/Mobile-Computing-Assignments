package com.example.spellme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;

public class SecondActivity extends AppCompatActivity {

    private SecondFragment second_frag;
    private ListFragment list_frag;

    private DetailsFragment details_frag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);


        FragmentManager fmanager = getSupportFragmentManager();
        FragmentTransaction ftransaction = fmanager.beginTransaction();

        second_frag = new SecondFragment();
        ftransaction.add(R.id.second_container, second_frag);

        list_frag = new ListFragment();
        ftransaction.add(R.id.list_container, list_frag);
        ftransaction.commit();
    }

    public void onItemClicked(String JSON, String word, int position){
//        Log.d("---------------------------INFO ", "2nd activity listener called");
        details_frag = new DetailsFragment(JSON, word, position);
        FragmentManager fmanager = getSupportFragmentManager();
        FragmentTransaction ftransaction = fmanager.beginTransaction();

        ftransaction.add(R.id.list_container, details_frag);

        // Add the transaction to the back stack
        ftransaction.addToBackStack(null);

        ftransaction.replace(R.id.list_container, details_frag);
        ftransaction.commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        FragmentManager fragmentManager = getSupportFragmentManager();

        if (fragmentManager.getBackStackEntryCount() > 0) {
            // Pop the back stack
            fragmentManager.popBackStack();
        } else {
            // If there is no back stack entry, call the super method
            super.onBackPressed();
        }
    }
}