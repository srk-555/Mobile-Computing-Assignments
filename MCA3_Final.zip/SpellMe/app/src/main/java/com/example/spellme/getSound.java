package com.example.spellme;


import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class getSound extends AsyncTask<URL,Void,InputStream> {
    private InputStream inputStream = null;
    private Context thisContext;
    public getSound(Context con, SecondFragment activity){
        this.thisContext = con;
//        Log.d("--------------getWord INFO", "inside got in 3");
    }
    @Override
    protected InputStream doInBackground(URL... urls) {
        URL url = null;
        HttpURLConnection connection = null;

        try {
//            Log.d("--------------getWord INFO", "inside got in try");
            connection = (HttpURLConnection) urls[0].openConnection();
//            Log.d();
            connection.setReadTimeout(15000);
            connection.setConnectTimeout(20000);
            connection.setRequestMethod("GET");
            connection.connect();
            int status = connection.getResponseCode();
//            Log.d("--------------getWord INFO status is ", String.valueOf(status));
            switch (status) {
                case 200:
                case 201:
//                    Log.d("--------------getWord INFO", "inside got in 2 case 201");
                    inputStream = connection.getInputStream();
                    if(inputStream == null) {
                        ((Activity)thisContext).runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(thisContext, "No audio available for this word", Toast.LENGTH_SHORT).show();
                            }
                        });
                        return null;

                    } else {
                    File file = new File(thisContext.getCacheDir(), "dummy.mp3");
                    FileOutputStream os = new FileOutputStream(file);

                    byte[] buffer = new byte[1024];
                    int len;

                    while((len=inputStream.read(buffer))>0){
                        os.write(buffer, 0, len);
                    }

                        os.close();
                        inputStream.close();

                        ((Activity)thisContext).runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(thisContext, "Playing Word Sound", Toast.LENGTH_SHORT).show();
                            }
                        });

                        MediaPlayer mediaPlayer = new MediaPlayer();
                        mediaPlayer.setDataSource(file.getAbsolutePath());
                        mediaPlayer.prepare();
                        mediaPlayer.start();
                    }
                    return inputStream;
                default:
                    return null;
            }
        } catch (Exception e) {
            Log.e("getSound", "Error while downloading mp3 file from URL: " + urls[0], e);
            return null;
        }finally {
            if(connection != null)
            {
                connection.disconnect();
            }
        }
    }

}
