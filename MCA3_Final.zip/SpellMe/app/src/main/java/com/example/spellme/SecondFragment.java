package com.example.spellme;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class SecondFragment extends Fragment{
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private ImageButton playSound;
    private TextView input;
    private String retrievedWord;
    private String retrievedJSON;
    private String audiourl = "";
    private String wordTitle = "Word title appears here";
    View rootView;
    TextView inputTextView;
    List<MyModel> myModelList;
    CustomAdapter customAdapter;
    public SecondFragment() {
        // Required empty public constructor
    }

    public static MainFragment newInstance(String param1, String param2) {
        MainFragment fragment = new MainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView =  inflater.inflate(R.layout.fragment_second, container, false);
        inputTextView = rootView.findViewById(R.id.word_title);

        playSound = rootView.findViewById(R.id.imageButton);
        // Retrieve the string extra with the key "JSON"
        retrievedJSON = getActivity().getIntent().getStringExtra("JSON");
        try {
            JSONArray jsonArray = new JSONArray(retrievedJSON);
//            Log.d("--------------------INFO [0]", String.valueOf(jsonArray.getJSONObject(0)));
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            if(jsonObject.has("word")){
                wordTitle = jsonObject.getString("word");
            }
            else{
                wordTitle = getActivity().getIntent().getStringExtra("word");
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        inputTextView.setText(wordTitle.toUpperCase());
        inputTextView.setLetterSpacing(0.1f);
//mt22069
        try {
            JSONArray jsonArray = new JSONArray(retrievedJSON);
//            Log.d("--------------------INFO [0]", String.valueOf(jsonArray.getJSONObject(0)));
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (jsonObject.has("phonetics")) {
                    JSONArray phonecticsArray = jsonObject.getJSONArray("phonetics");

                    for(int k=0; k<phonecticsArray.length(); k++){
                        JSONObject phoneticObject = phonecticsArray.getJSONObject(k);
                        if(phoneticObject.has("audio")){
                            String audio = phoneticObject.getString("audio");
                            if(audio.isEmpty() || audio == "" || audio == null){
                            }
                            else{//mt22069
                                if (audiourl == ""){
//                                    Log.e("Entered if - ", audio);
                                    audiourl = audio.trim();
//                                    Log.e("Audio URL in else is ->", audiourl);
                                }
                            }
                        }
                    }
                }
            }
        }catch (JSONException e) {
            throw new RuntimeException(e);
        }

        // Set an OnClickListener on the button
        playSound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform the necessary actions when the button is clicked
                ConnectivityManager cm = (ConnectivityManager)requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netinfo = cm.getActiveNetworkInfo();

                if(netinfo == null || !netinfo.isConnected()) {
                    Toast.makeText(getActivity(), "Not connected to Network", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(wordTitle==null || wordTitle=="Word title appears here"){
                        Toast.makeText(getActivity(),"Cannot retrieve word to play sound", Toast.LENGTH_LONG).show();
                        return;
                    }
                    else {
                        if(audiourl=="" || audiourl.isEmpty()){
                            Toast.makeText(getActivity(), "No audio available for this word", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            URL url = null;
                            try {
                                url = new URL(audiourl.toLowerCase());
                                AsyncTask<URL, Void, InputStream> task = new getSound(getContext(),SecondFragment.this).execute(url);
                            } catch (MalformedURLException e) {
                                throw new RuntimeException(e);
                            }

                        }
//                        URL url = new URL("https://api.dictionaryapi.dev/api/v2/entries/en/" + inputWord.getText().toString().trim().toLowerCase());
//                        AsyncTask<URL, Void, String> task = new getWord(getActivity()).execute(url);
                    }
                }
            }
        });

        return rootView;
    }
}