package com.example.spellme;

public class MyModel {
    String textContent = "";
    int position;

    public MyModel(String textContent, int position) {
        this.textContent = textContent;
        this.position = position;
    }

    public String getTextContent() {
        return textContent;
    }
    public int getTextPosition(){return position;}

    public void setTextContent(String textContent) {
        this.textContent = textContent;
    }
}