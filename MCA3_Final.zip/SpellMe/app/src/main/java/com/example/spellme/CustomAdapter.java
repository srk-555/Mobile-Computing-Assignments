package com.example.spellme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {
    private Context context;

    private List<MyModel> list;

    private View rootView;
    private int isFromDetails;
    private SelectListener listener;
    //Creating constructor
    public CustomAdapter(Context context, List<MyModel> list, SelectListener listener, int isFromDetails) {
        this.context = context;
        this.list = list;
        this.rootView = rootView;
        this.listener = listener;
        this.isFromDetails = isFromDetails;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (isFromDetails == 1){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.details_item_modifier, parent, false);
        }
        else{
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_modifier, parent, false);
        }
        CustomViewHolder viewHolder = new CustomViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
//        Log.d("-------------------INF0 - list data position - ",  String.valueOf(holder.getAdapterPosition()));
        holder.getTextView().setText(list.get(position).getTextContent());

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onItemClicked(list.get(holder.getAdapterPosition()));
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {

        public final TextView textList;
        public CardView cardView;
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
//            Log.d("----------------INFO", "this is called");
            textList = itemView.findViewById(R.id.listTextView);

            cardView = itemView.findViewById(R.id.main_container);
//            Log.d("-----------INFO itemView is  - ", String.valueOf(itemView.findViewById(R.id.recycler)));
//            Log.d("-----------INFO textlist in viewholder is - ", String.valueOf(R.id.recycler));

        }

        public TextView getTextView(){
            return textList;
        }
    }
}