package com.example.spellme;

public interface SelectListener {
    void onItemClicked(MyModel mymodel);
}
