package com.example.spellme;

public interface OnDataSendToActivity {
    public void updateUI(String str);
}