package com.example.spellme;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class DetailsFragment extends Fragment implements SelectListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;


    private String mParam2;
    View details_listRootView;
    RecyclerView details_recyclerView;
    List<MyModel> myModelList;
    CustomAdapter customAdapter;
    private String retrievedJSON;
    private String retrievedPOS;
    private int position;
    public DetailsFragment(String JSON, String word, int position) {
        this.retrievedJSON = JSON;
        this.retrievedPOS = word;
        this.position = position;
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    public String convertToString(JSONArray jsonArray) throws JSONException {
        StringJoiner joiner = new StringJoiner(", "); //Initializing a StringJoiner with comma separator
        for (int i = 0; i < jsonArray.length(); i++) {
            Object obj = jsonArray.get(i); //Get the element at the current index
            joiner.add(obj.toString());
        }
        String result = joiner.toString();
        return result;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        details_listRootView = inflater.inflate(R.layout.fragment_details, container, false);
        details_recyclerView = details_listRootView.findViewById(R.id.details_recycler);
        myModelList = new ArrayList<>();

        try {
            JSONArray jsonArray = new JSONArray(retrievedJSON);
            JSONObject jsonObject = jsonArray.getJSONObject(0);

            myModelList.add(new MyModel(String.valueOf(jsonObject.getString("word").toLowerCase())+" as "+String.valueOf(retrievedPOS.toUpperCase()), 0));
            if(jsonObject.has("meanings")){
                JSONArray meaningsArray = jsonObject.getJSONArray("meanings");
                JSONObject meaningObject = meaningsArray.getJSONObject(this.position);

                if(meaningObject.has("synonyms")){
                    if(meaningObject.getJSONArray("synonyms").length()>0){
                        myModelList.add(new MyModel("Synonyms : \n"+convertToString(meaningObject.getJSONArray("synonyms")), 1));
                    }
                }
                if(meaningObject.has("antonyms")){
                    if(meaningObject.getJSONArray("antonyms").length()>0){
                        myModelList.add(new MyModel("Antonyms : \n"+convertToString(meaningObject.getJSONArray("antonyms")), 2));
                    }
                }
                if(meaningObject.has("definitions")){
                    JSONArray definitionsArray = meaningObject.getJSONArray("definitions");

                    for(int i=0; i<definitionsArray.length(); i++) {
                        JSONObject definitionObject = definitionsArray.getJSONObject(i);
                        StringBuilder result = new StringBuilder();
                        if(definitionObject.has("definition")){
                            String str = definitionObject.getString("definition");
                            str = String.valueOf(str);
                            result.append("Definition : \n" + str);
//                            Log.e("Definition is - ", definitionObject.getString("definition"));

                        }
                        if(definitionObject.has("example")){
                            result.append("\n\nExample : \n" + String.valueOf(definitionObject.getString("example")));
                        }
                        if(definitionObject.has("synonyms") && definitionObject.getJSONArray("synonyms").length()>0){
                            result.append("\n\nSynonyms : \n" + convertToString(definitionObject.getJSONArray("synonyms")));
                        }
                        if(definitionObject.has("antonyms") && definitionObject.getJSONArray("antonyms").length()>0){
                            result.append("\n\nAntonyms : \n" + convertToString(definitionObject.getJSONArray("antonyms")));
                        }

                        if(result.length()!=0) {
                            myModelList.add(new MyModel(result.toString(), 2));
                        }
                    }
                }
//                for (int i = 0; i < meaningsArray.length(); i++) {
//                    JSONObject meaningObject = meaningsArray.getJSONObject(i);
//                    if(meaningObject.has("definitions")) {
//                        String partOfSpeech = meaningObject.getString("definitions");
//                        myModelList.add(new MyModel(partOfSpeech, i+1));
//                    }
//                }
            }
            else{
                Toast.makeText(getActivity(), "Word has no meanings", Toast.LENGTH_SHORT).show();
            }

        }catch (JSONException e) {
            e.printStackTrace();
            //throw new RuntimeException(e);

        }

        details_recyclerView.setHasFixedSize(false);
        details_recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        customAdapter = new CustomAdapter(getContext(), myModelList, this, 1);
        details_recyclerView.setAdapter(customAdapter);


        return details_listRootView;
    }

    @Override
    public void onItemClicked(MyModel mymodel) {

    }
}