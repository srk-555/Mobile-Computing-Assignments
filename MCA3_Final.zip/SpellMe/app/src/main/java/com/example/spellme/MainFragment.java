package com.example.spellme;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.IOException;
import java.net.URL;

public class MainFragment extends Fragment implements OnDataSendToActivity{
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private Button search;
    private EditText inputWord;

    private View rootView;
    public MainFragment() {
        // Required empty public constructor
    }

    public static MainFragment newInstance(String param1, String param2) {
        MainFragment fragment = new MainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView =  inflater.inflate(R.layout.fragment_main, container, false);

        search = rootView.findViewById(R.id.search);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    fetchMon();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        return rootView;
    }


    void fetchMon() throws IOException {
        ConnectivityManager cm = (ConnectivityManager)requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netinfo = cm.getActiveNetworkInfo();

        if(netinfo == null || !netinfo.isConnected()) {
            Toast.makeText(getActivity(), "Not connected to Network", Toast.LENGTH_SHORT).show();
        }
        else
        {
//            EditText monName = rootView.findViewById(R.id.input);
            inputWord = rootView.findViewById(R.id.input);
//            Log.e("main word ", String.valueOf(inputWord.getText().toString().trim().toLowerCase().getClass()));


            if(inputWord==null || inputWord.getText().toString().trim().isEmpty()){
                Toast.makeText(getActivity(),"Word Field is Empty", Toast.LENGTH_LONG).show();
                return;
            }
            else if(!inputWord.getText().toString().trim().matches("[a-zA-Z]+")){
                Toast.makeText(getActivity(),"Only characters are allowed", Toast.LENGTH_LONG).show();
                return;
            }
            else {
                URL url = new URL("https://api.dictionaryapi.dev/api/v2/entries/en/" + inputWord.getText().toString().trim().toLowerCase());
                AsyncTask<URL, Void, String> task = new getWord(this).execute(url);
            }
        }
    }


    public void updateUI(String data) {

        Intent intent = new Intent(getActivity(),  SecondActivity.class);
//        JSONArray jsonArray = new JSONArray(data);
////            Log.d("--------------------INFO [0]", String.valueOf(jsonArray.getJSONObject(0)));
//        JSONObject jsonObject = jsonArray.getJSONObject(0);
        if(data.equals("FAILED") || data.equals(""))
        {
            Toast.makeText(getActivity(),"Word not found in the dictionary", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(getActivity(), "Word found", Toast.LENGTH_SHORT).show();
            intent.putExtra("JSON", data);
            intent.putExtra("word", inputWord.getText().toString().trim().toLowerCase());
            startActivity(intent);
//            Log.d("-------------------------INFO - JSON data - ", data);
        }

    }
}