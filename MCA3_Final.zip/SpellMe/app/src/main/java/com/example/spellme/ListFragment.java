package com.example.spellme;


import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class ListFragment extends Fragment implements SelectListener{

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private String retrievedJSON;

    View listRootView;
    RecyclerView recyclerView;
    List<MyModel> myModelList;
    CustomAdapter customAdapter;


    public ListFragment() {
        // Required empty public constructor
    }


    public static ListFragment newInstance(String param1, String param2) {
        ListFragment fragment = new ListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

//        rootView =  inflater.inflate(R.layout.fragment_second, container, false);
        listRootView = inflater.inflate(R.layout.fragment_list, container, false);

        recyclerView = listRootView.findViewById(R.id.recycler);


        // Retrieve the string extra with the key "JSON"
        retrievedJSON = getActivity().getIntent().getStringExtra("JSON");
        myModelList = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(retrievedJSON);
//            Log.d("--------------------INFO [0]", String.valueOf(jsonArray.getJSONObject(0)));
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            if(jsonObject.has("meanings")){
                JSONArray meaningsArray = jsonObject.getJSONArray("meanings");

                for (int i = 0; i < meaningsArray.length(); i++) {
                    JSONObject meaningObject = meaningsArray.getJSONObject(i);
                    if(meaningObject.has("partOfSpeech")) {
                        String partOfSpeech = meaningObject.getString("partOfSpeech");
                        myModelList.add(new MyModel(partOfSpeech, i));
                    }
                }
            }
            else{
                Toast.makeText(getActivity(), "Word has no meanings", Toast.LENGTH_SHORT).show();
            }

        }catch (JSONException e) {
            e.printStackTrace();
            //throw new RuntimeException(e);

        }

        recyclerView.setHasFixedSize(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        customAdapter = new CustomAdapter(getContext(), myModelList, this, 0);
        recyclerView.setAdapter(customAdapter);


        return listRootView;
    }


    @Override
    public void onItemClicked(MyModel mymodel) {
        SecondActivity secondActivity = (SecondActivity) getActivity();
        secondActivity.onItemClicked(retrievedJSON, mymodel.getTextContent().toLowerCase(), mymodel.getTextPosition());
    }
}


